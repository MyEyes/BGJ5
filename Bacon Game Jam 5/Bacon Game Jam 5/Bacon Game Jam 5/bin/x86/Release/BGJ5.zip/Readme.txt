Full source at https://github.com/MyEyes/BGJ5/

**************Requirements***************
This game requires the XNA 4.0 refresh redist to run
as well as .Net 4.0.

XNA redist: http://www.microsoft.com/en-us/download/details.aspx?id=20914

****************Controls*****************
Move					- W A S D
Skip Intro				- ESC
Accelerate Intro Text	- Space
Restart Level			- ESC

****************Gameplay*****************

You are a single light. Small and dim and weak.

But of course this wouldn't be a videogame 
if you couldn't grow bigger and blow shit up
to take revenge for your enslaved light bretheren.

There will be darkness lurking around.
If it notices you you will have no choice but to "fight".
It will suck up your light and you will suck up some of it's darkness.

If you run out of light, you die.
Luckily if the darkness runs out of, well, darkness, it dies as well.
And not just that, it will leave behind a small sphere of light.

At the beginning of the game there are 8 spheres of light hidden on the map.
Those spheres make you stronger. You absorb their light to grow.
If you use it up, another one will spawn somewhere on the map.

And last but not least, there is a powerup that I will not explain further.
Just so much about it. It is rare and it does not respawn light the light spheres do.
So use it wisely.

Of course if you take out all but one of the lights, there is a small surprise as well.

Have fun playing.

****************Credits******************
Programming:
	Nils Ole Timm aka Firzen_
Assets:
	Textures:
		Noise texture	-	http://gimpguru.org/tutorials/texturing/ found here
		TileSet			-	Firzen_
	Sounds:
		Clapping 		-	Iwan Gabovitch http://opengameart.org/users/qubodup
		Hit and Heal 	-	Iwan Gabovitch http://opengameart.org/users/qubodup
		Heartbeat  		-	Iwan Gabovitch http://opengameart.org/users/qubodup
		Fanfare			-	http://www.wavsource.com/sfx/sfx2.htm
		Explosion		-	Lamoot http://opengameart.org/content/big-explosion
		Rock Music		-	PlayOnLoop http://opengameart.org/content/the-survival-heavy-rock-loop
		Evil Laugh		-	Venn Stone http://opengameart.org/content/evil-laughter-0
		Ambient Sound	-	cougarmagnification http://opengameart.org/content/stirring-ambience